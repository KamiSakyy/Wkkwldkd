export interface FailoverHop {
  providerSlug: string;
  providerName: string;
  modelId: string;
  status: "success" | "failed" | "skipped";
  statusCode?: number;
  latencyMs: number;
  error?: string;
}

export interface AIProvider {
  id: number;
  slug: string;
  name: string;
  vendor: string;
  gateway: string;
  modelId: string;
  endpoint: string;
  publicKeyLabel: string;
  category: string;
  description: string;
  badgeText: string;
  supportsVision: boolean;
  supportsStream: boolean;
  contextWindow: number;
  isEnabled: boolean;
  priority: number;
  avgLatencyMs: number;
  successRate: number;
  totalRequests: number;
  failedRequests: number;
  lastStatus: string;
}

export interface ChatSession {
  id: number;
  title: string;
  routingMode: string;
  systemPersona: string;
  chatMode?: string;
  repoFullName?: string | null;
  repoBranch?: string | null;
  messageCount: number;
  totalTokens: number;
  isPinned: boolean;
  updatedAt: string;
}

export interface ChatMessage {
  id: number;
  sessionId: number;
  role: "user" | "assistant";
  kind?: string;
  content: string;
  imageUrl?: string | null;
  attachmentDataUrl?: string | null;
  groupKey?: string | null;
  reasoningTrace?: string | null;
  providerSlug?: string | null;
  providerName?: string | null;
  modelId?: string | null;
  latencyMs?: number | null;
  tokensPerSec?: number | null;
  tokenCount?: number | null;
  routingReason?: string | null;
  failoverLog?: FailoverHop[] | null;
  animeData?: { type: "cards" | "calendar"; items: unknown[] } | null;
  imagesData?: { image: string; thumbnail: string; title: string; source: string }[] | null;
  createdAt: string;
}

export interface StreamingState {
  providerName: string;
  modelId: string;
  attempt: number;
  status: string;
  content: string;
  reasoning: string;
  hops: FailoverHop[];
}

export type Block =
  | { kind: "message"; message: ChatMessage }
  | { kind: "arena"; key: string; messages: ChatMessage[] };

export function relativeTime(value: string) {
  const minutes = Math.max(0, Math.round((Date.now() - new Date(value).getTime()) / 60000));
  if (minutes < 2) return "сейчас";
  if (minutes < 60) return `${minutes} мин`;
  if (minutes < 1440) return `${Math.round(minutes / 60)} ч`;
  return `${Math.round(minutes / 1440)} д`;
}

export function formatLatency(ms?: number | null) {
  if (!ms) return "";
  return ms < 1000 ? `${ms} мс` : `${(ms / 1000).toFixed(1)} с`;
}
