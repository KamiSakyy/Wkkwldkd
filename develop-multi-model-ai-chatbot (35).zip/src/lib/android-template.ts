// A complete, self-contained Android app project that builds a real APK on
// GitHub Actions with no local setup. Uses Gradle's setup-gradle action so no
// committed gradle-wrapper binary is needed.

export interface TemplateFile {
  path: string;
  content: string;
}

// Build workflow that generates the Gradle wrapper on CI, then builds the APK.
export function androidBuildWorkflow(): string {
  // Uses the Android SDK preinstalled on ubuntu-latest (ANDROID_HOME set) —
  // avoids the flaky setup-android licensing step. Accepts licenses manually.
  return `name: Build APK

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4

      - name: Accept Android SDK licenses
        run: yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses || true

      - name: Install required SDK packages
        run: "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

      - name: Generate Gradle wrapper
        run: gradle wrapper --gradle-version 8.7

      - name: Build debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
`;
}

// Returns the full set of files for a working Kotlin Android app.
// `appName` and `description` customize the sample screen.
export function androidAppFiles(appName: string, description: string): TemplateFile[] {
  const safeName = appName.replace(/[^A-Za-z0-9 ]/g, "").trim() || "AetherApp";
  const displayName = appName.trim() || "AETHER App";

  return [
    {
      path: "settings.gradle.kts",
      content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${safeName}"
include(":app")
`,
    },
    {
      path: "build.gradle.kts",
      content: `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`,
    },
    {
      path: "gradle.properties",
      content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
    },
    {
      path: "app/build.gradle.kts",
      content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aether.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aether.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
}
`,
    },
    {
      path: "app/src/main/AndroidManifest.xml",
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="${displayName}"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`,
    },
    {
      path: "app/src/main/java/com/aether/app/MainActivity.kt",
      content: `package com.aether.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AppScreen()
            }
        }
    }
}

@Composable
fun AppScreen() {
    var count by remember { mutableStateOf(0) }
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("${displayName}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("${description.replace(/"/g, "\\\"")}", fontSize = 16.sp)
            Spacer(Modifier.height(36.dp))
            Text("Нажато раз: \$count", fontSize = 22.sp)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { count++ }) {
                Text("Нажми меня")
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { count = 0 }) {
                Text("Сбросить")
            }
        }
    }
}
`,
    },
    {
      path: ".github/workflows/build-apk.yml",
      content: androidBuildWorkflow(),
    },
    {
      path: "README.md",
      content: `# ${displayName}

${description}

Android-приложение на Kotlin + Jetpack Compose. Собрано автоматически ИИ-агентом AETHER.

## Сборка
APK собирается через GitHub Actions (workflow **Build APK**). Готовый файл — в артефактах запуска (\`app-debug-apk\`).
`,
    },
  ];
}
