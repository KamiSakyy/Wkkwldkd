// Real image search (DuckDuckGo, no API key) so Aya can find & send photos.

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

export interface ImageResult {
  image: string;
  thumbnail: string;
  title: string;
  source: string;
}

export async function searchImages(query: string, limit = 8, safe = true): Promise<ImageResult[]> {
  try {
    // 1) get vqd token
    const tokenRes = await fetch(`https://duckduckgo.com/?q=${encodeURIComponent(query)}&iax=images&ia=images`, {
      headers: { "User-Agent": UA },
      signal: AbortSignal.timeout(12000),
    });
    const html = await tokenRes.text();
    const vqd = html.match(/vqd=["']?([\d-]+)["']?/)?.[1] || html.match(/vqd=([\d-]+)&/)?.[1];
    if (!vqd) return [];

    // 2) fetch images
    const p = safe ? "1" : "-2";
    const res = await fetch(
      `https://duckduckgo.com/i.js?l=us-en&o=json&q=${encodeURIComponent(query)}&vqd=${vqd}&f=,,,&p=${p}`,
      { headers: { "User-Agent": UA, Referer: "https://duckduckgo.com/" }, signal: AbortSignal.timeout(12000) }
    );
    if (!res.ok) return [];
    const data = await res.json();
    const results = (data.results || []) as Array<Record<string, unknown>>;
    return results
      .filter((r) => r.image && String(r.image).startsWith("http"))
      .slice(0, limit)
      .map((r) => ({
        image: String(r.image),
        thumbnail: String(r.thumbnail || r.image),
        title: String(r.title || ""),
        source: String(r.url || r.source || ""),
      }));
  } catch {
    return [];
  }
}

// Detect "find/give me photos/arts of X" requests
const IMG_TRIGGERS = [
  "фотки", "фото", "картинки", "картинку", "арт", "арты", "изображения", "пикчи",
  "покажи фото", "найди фото", "дай фото", "дай арт", "скинь фото", "скинь арт",
  "обои", "wallpaper", "images of", "photos of", "pictures of", "art of", "найди картинки",
];

export function detectImageSearch(prompt: string): { wants: boolean; query: string } {
  const l = prompt.toLowerCase();
  const wants = IMG_TRIGGERS.some((t) => l.includes(t)) && /(найд|дай|скинь|покаж|show|find|нужн|хочу|прислать)/i.test(l);
  if (!wants) return { wants: false, query: "" };
  // strip trigger/filler words to build a clean image query.
  // (JS \b doesn't work reliably with Cyrillic, so match words with spaces.)
  const stop = ["найди в интернете", "в интернете", "найди", "найти", "дай-ка", "дай", "скинь", "покажи", "пришли", "пожалуйста", "плиз", "интернет", "фотки", "фоток", "фотографии", "фотография", "фото", "картинки", "картинок", "картинку", "картина", "арты", "артов", "арт", "изображения", "изображение", "пикчи", "пикч", "обои", "нужны", "нужно", "хочу", "хочется", "срочно", "мне", "show", "find", "images", "image", "photos", "photo", "pictures", "picture", "wallpaper"];
  let q = " " + prompt.toLowerCase().replace(/[?!.,]+/g, " ") + " ";
  for (const w of stop) q = q.split(` ${w} `).join(" ");
  const query = q.replace(/\s+/g, " ").trim();
  return { wants: true, query: query || prompt };
}
