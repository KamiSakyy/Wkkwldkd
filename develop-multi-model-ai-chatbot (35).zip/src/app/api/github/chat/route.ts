import { NextRequest } from "next/server";
import { db } from "@/db";
import { chatMessages, chatSessions } from "@/db/schema";
import { ensureSeededDatabase, askAgent, councilCode, ChatTurn } from "@/lib/ai-router";
import {
  getStoredToken,
  listTree,
  readFile,
  writeFile,
  listWorkflows,
  dispatchWorkflow,
  dispatchAndTrack,
  triggerBuildByPush,
  deleteFile,
  commitFiles,
  getWorkflowId,
  listWorkflowRuns,
  countRunJobs,
  getLatestRun,
  getRun,
  listArtifacts,
  parseWriteOps,
  parseAgentCommands,
  waitForRunId,
  getFailedLogs,
} from "@/lib/github";
import { androidAppFiles } from "@/lib/android-template";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 800;

const MAX_STEPS = 10;

export async function POST(req: NextRequest) {
  await ensureSeededDatabase();
  const body = await req.json().catch(() => ({}));
  const prompt = String(body.prompt || "").trim();
  const repo = String(body.repo || "");
  const branch = String(body.branch || "main");
  let sessionId = Number(body.sessionId) || 0;

  if (!prompt) return Response.json({ error: "Пустой запрос" }, { status: 400 });
  const stored = await getStoredToken();
  if (!stored) return Response.json({ error: "GitHub не подключён" }, { status: 401 });
  if (!repo) return Response.json({ error: "Не выбран репозиторий" }, { status: 400 });
  const token = stored.token;

  let session = null;
  if (sessionId) {
    const [s] = await db.select().from(chatSessions).where(eq(chatSessions.id, sessionId));
    session = s || null;
  }
  if (!session) {
    const [created] = await db
      .insert(chatSessions)
      .values({ title: `GitHub · ${repo.split("/")[1] || repo}`, chatMode: "github", repoFullName: repo, repoBranch: branch })
      .returning();
    session = created;
    sessionId = created.id;
  }

  const history = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId))
    .orderBy(asc(chatMessages.createdAt), asc(chatMessages.id));

  const [userMessage] = await db
    .insert(chatMessages)
    .values({ sessionId, role: "user", kind: "text", content: prompt })
    .returning();

  const encoder = new TextEncoder();
  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort());

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (o: Record<string, unknown>) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(o)}\n\n`));
        } catch {
          closed = true;
        }
      };

      try {
        send({ type: "start", userMessage, activeSessionId: sessionId });

        // Initial repo snapshot
        send({ type: "status", text: "Читаю структуру репозитория…" });
        const tree = await listTree(token, repo, branch);
        const fileList = tree.filter((t) => t.type === "blob").map((t) => t.path);
        const workflows = await listWorkflows(token, repo);

        const system =
          `Ты — автономный ИИ-инженер (agent mode, как atena.ai), ПОДКЛЮЧЁННЫЙ к GitHub-репозиторию «${repo}» (ветка ${branch}) с правами записи. ` +
          `Ты НЕ даёшь инструкции пользователю — ты ДЕЛАЕШЬ всё САМ через команды-инструменты. У пользователя нет терминала.\n\n` +
          `ИНСТРУМЕНТЫ (выводи прямо в ответе, система выполнит и вернёт результат):\n` +
          `[[READ_FILE: путь]] — прочитать файл.\n` +
          `[[LIST_FILES]] — список файлов.\n` +
          `[[WRITE_FILE: путь]]\n<ПОЛНОЕ содержимое>\n[[/WRITE_FILE]] — создать/изменить файл (коммит). Можно НЕСКОЛЬКО WRITE_FILE в одном ответе.\n` +
          `[[RUN_WORKFLOW: файл.yml]] — запустить сборку GitHub Actions.\n` +
          `[[CHECK_BUILD]] — статус сборки.\n\n` +
          `КАЧЕСТВО — ГЛАВНОЕ. Делай МАКСИМАЛЬНО качественно и полно, не торопись, не экономь:\n` +
          `— Создавай ВСЕ нужные файлы с ПОЛНЫМ, продуманным, рабочим кодом. Никаких заглушек, "// TODO", пустышек или «здесь будет код».\n` +
          `— Для САЙТА: современный красивый дизайн (адаптивная вёрстка, аккуратные стили, шрифты, анимации), несколько секций, реальный контент, рабочий JS. Не одну голую страницу «Hello», а законченный качественный сайт.\n` +
          `— Разбивай на файлы (index.html, styles.css, script.js и т.д.), пиши подробно.\n` +
          `— Для приложения/скрипта: полноценная логика + зависимости + README.\n` +
          `— Действуй пошагово, доводи задачу до конца: сначала главные файлы, потом дополни детали в следующих шагах.\n\n` +
          `ЗАПРЕЩЕНО: отвечать «вот как сделать», «создайте вручную», давать инструкции без команд, создавать пустые/примитивные файлы.\n` +
          `Пиши коротко на русском: что делаешь + сами команды с полным кодом.`;

        const repoContext =
          `Файлы репозитория (${fileList.length}):\n${fileList.slice(0, 80).join("\n") || "(пусто)"}\n` +
          `Workflows: ${workflows.length ? workflows.map((w) => w.path).join(", ") : "нет"}`;

        const convo: ChatTurn[] = [
          { role: "system", content: repoContext },
          ...history.slice(-6).map((m) => ({
            role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user",
            content: m.content,
          })),
          { role: "user", content: prompt },
        ];

        const transcript: string[] = [];
        const commits: { path: string; url?: string; ok: boolean; error?: string }[] = [];
        let providerName = "Codestral 25.01";
        let providerSlug = "mistral-codestral";
        let modelId = "codestral-latest";

        // ── Special case: "build a REAL Android app + APK" ──────────────────
        // Instead of hoping the LLM writes 8 correct Gradle files, scaffold a
        // proven working project directly, then run the build.
        const wantsAndroidApp = /(apk|андроид|android)/i.test(prompt) && /(прилож|app|созда|сделай|собери|build)/i.test(prompt);
        if (wantsAndroidApp) {
          send({ type: "status", text: "Придумываю приложение…" });
          // Ask a model for a name + description + what the app does
          let appName = "AETHER App";
          let appDesc = "Демо-приложение, созданное ИИ-агентом.";
          try {
            const idea = await askAgent(
              "Ты придумываешь мобильное приложение. Верни СТРОГО JSON: {\"name\":\"короткое название\",\"description\":\"1 предложение что делает приложение\"}. Только JSON.",
              [{ role: "user", content: `Придумай Android-приложение по запросу пользователя: "${prompt}". Название на русском или английском, описание на русском.` }],
              "gpt-oss-20b",
              abort.signal
            );
            const j = JSON.parse(idea.content.slice(idea.content.indexOf("{"), idea.content.lastIndexOf("}") + 1));
            if (j.name) appName = String(j.name).slice(0, 40);
            if (j.description) appDesc = String(j.description).slice(0, 160);
          } catch {
            /* use defaults */
          }

          send({ type: "delta", content: `Создаю настоящее Android-приложение **«${appName}»** — ${appDesc}\n\nПишу полный проект (Kotlin + Jetpack Compose) и запускаю сборку APK.\n` });

          // Remove any OLD/interfering workflows (e.g. leftover deploy.yml) so
          // only our Build APK workflow runs on push.
          try {
            const existingWfs = await listWorkflows(token, repo);
            for (const w of existingWfs) {
              const name = w.path.split("/").pop() || "";
              if (name && name !== "build-apk.yml") {
                send({ type: "status", text: `Удаляю лишний workflow ${name}…` });
                await deleteFile(token, repo, w.path, branch, `AETHER: убираю лишний workflow ${name}`);
              }
            }
          } catch {
            /* ignore */
          }

          // Commit ALL files in ONE atomic commit → exactly ONE build run.
          const files = androidAppFiles(appName, appDesc);
          send({ type: "status", text: `Коммичу проект (${files.length} файлов) одним коммитом…` });
          const wfId = await getWorkflowId(token, repo, "build-apk.yml");
          const beforeRuns = wfId ? await listWorkflowRuns(token, repo, wfId, 10) : [];
          const beforeSet = new Set(beforeRuns.map((r) => r.id));
          const commitRes = await commitFiles({ token, fullName: repo, branch, files, message: `AETHER: приложение ${appName}` });
          for (const f of files) {
            commits.push({ path: f.path, ok: commitRes.ok, url: commitRes.commitUrl, error: commitRes.error });
            send({ type: "commit", path: f.path, ok: commitRes.ok, url: commitRes.commitUrl, error: commitRes.error });
          }

          // ── Build → wait 100% → auto-fix loop (up to 5 attempts) ──────────
          let runUrl = "";
          let built = false;
          const MAX_FIX = 3;
          let prevErrSig = "";
          let trackSet = beforeSet;
          for (let attempt = 1; attempt <= MAX_FIX; attempt++) {
            if (abort.signal.aborted) break;
            send({ type: "status", text: attempt === 1 ? "Запускаю сборку APK…" : `Повторная сборка (попытка ${attempt})…` });

            // Find the build-apk run created by our commit (attempt 1) or trigger a fresh one
            let disp: { ok: boolean; runId?: number; error?: string };
            if (attempt === 1) {
              // wait for the run from the atomic commit
              let runId: number | undefined;
              const curWf = wfId || (await getWorkflowId(token, repo, "build-apk.yml"));
              for (let i = 0; i < 30 && curWf; i++) {
                if (abort.signal.aborted) break;
                await new Promise((r) => setTimeout(r, 3000));
                const runs = await listWorkflowRuns(token, repo, curWf, 10);
                const fresh = runs.find((r) => !trackSet.has(r.id));
                if (fresh) { runId = fresh.id; break; }
              }
              disp = runId ? { ok: true, runId } : { ok: false, error: "Сборка не запустилась после коммита" };
            } else {
              disp = await triggerBuildByPush(token, repo, branch, "build-apk.yml", abort.signal);
            }
            if (!disp.ok || !disp.runId) { send({ type: "action", label: `❌ Не удалось запустить сборку: ${disp.error || "нет run"}` }); break; }
            send({ type: "action", label: `▶️ Сборка #${attempt} запущена (run ${disp.runId})` });

            // Wait for THIS EXACT run to reach status=completed on the runner
            send({ type: "status", text: "⏳ Жду, пока раннер GitHub Actions полностью завершится…" });
            let lastStatus = "";
            let run = null as Awaited<ReturnType<typeof getRun>>;
            if (disp.runId) {
              run = await waitForRunId(token, repo, disp.runId, (r) => {
                if (r.status !== lastStatus) {
                  lastStatus = r.status;
                  const label = r.status === "completed" ? `🏁 Раннер завершён · ${r.conclusion}` : `🔧 Раннер: ${r.status}`;
                  send({ type: "action", label, url: r.htmlUrl });
                }
              }, { signal: abort.signal });
            } else {
              const latest = await getLatestRun(token, repo);
              if (latest) run = await waitForRunId(token, repo, latest.id, undefined, { signal: abort.signal });
            }

            if (!run) { send({ type: "status", text: "Не удалось получить статус сборки." }); break; }
            runUrl = run.htmlUrl;

            // Только НАСТОЯЩИЙ success считается успехом.
            if (run.status === "completed" && run.conclusion === "success") {
              built = true;
              const arts = await listArtifacts(token, repo, run.id);
              send({ type: "action", label: `✅ APK реально собран! ${arts.map((a) => a.name).join(", ") || "app-debug-apk"}`, url: run.htmlUrl });
              break;
            }

            if (run.status !== "completed") {
              send({ type: "status", text: "Сборка ещё идёт (превышено время ожидания). Напишите «продолжи» для проверки." });
              break;
            }

            // Detect account-level Actions block: run failed instantly with NO jobs
            // (0 jobs + 0s duration = exhausted free minutes / spending limit).
            const jobCount = await countRunJobs(token, repo, run.id);
            if (jobCount === 0 && (run.conclusion === "failure" || run.conclusion === "startup_failure")) {
              send({ type: "action", label: "⚠️ GitHub Actions заблокирован на аккаунте", url: run.htmlUrl });
              send({
                type: "delta",
                content:
                  "\n\n⚠️ **GitHub Actions не запускает задачи на этом аккаунте.** Раннер завершается за 0 секунд без выполнения — GitHub блокирует запуск (это НЕ ошибка кода).\n\n" +
                  "Возможные причины и решения:\n" +
                  "1. **Закончились бесплатные минуты** (для приватных репо). → Сделайте репозиторий публичным или пополните: GitHub → Settings → Billing → Actions.\n" +
                  "2. **Аккаунт помечен как новый/подозрительный** — GitHub временно ограничивает Actions. → Подтвердите email/номер телефона в настройках GitHub, подождите и попробуйте позже.\n" +
                  "3. **Actions отключены в репозитории** → Settings → Actions → General → Allow all actions.\n\n" +
                  "✅ **Код приложения полностью готов и закоммичен в репозиторий.** Как только Actions разблокируются, напишите «собери APK» — сборка пройдёт автоматически. Также можно собрать проект локально: `./gradlew assembleDebug`.\n",
              });
              break;
            }

            // conclusion === failure/cancelled → read logs and fix
            send({ type: "status", text: `Сборка провалилась (${run.conclusion}). Читаю логи…` });
            const logs = await getFailedLogs(token, repo, run.id);

            // Stop if the SAME error repeats — auto-fix isn't making progress.
            const errSig = (logs || "").replace(/\d+/g, "").replace(/\s+/g, " ").slice(0, 300);
            if (attempt > 1 && errSig && errSig === prevErrSig) {
              send({ type: "action", label: "⏹ Одинаковая ошибка повторяется — останавливаюсь", url: run.htmlUrl });
              send({ type: "delta", content: `\n\nСборка падает с одной и той же ошибкой — автоматическое исправление не помогает. Последний лог:\n\`\`\`\n${(logs || "нет логов").slice(0, 600)}\n\`\`\`\nКод закоммичен, проверьте вручную: ${run.htmlUrl}\n` });
              break;
            }
            prevErrSig = errSig;
            send({ type: "delta", content: `\n\n⚠️ Сборка #${attempt} упала. Исправляю код…\n` });

            const fixSystem =
              `Ты — эксперт по сборке Android (Gradle/Kotlin). Сборка APK на GitHub Actions УПАЛА. ` +
              `Исправь причину, изменив нужные файлы. Выводи ТОЛЬКО команды [[WRITE_FILE: путь]]<полное новое содержимое>[[/WRITE_FILE]] для файлов, которые надо поправить. Кратко поясни причину одной фразой.`;
            const fixContent =
              `Проект (Kotlin + Jetpack Compose) в репозитории «${repo}». Логи ошибки сборки:\n\n${logs || "(логи недоступны)"}\n\n` +
              `Текущие ключевые файлы:\n` +
              `--- app/build.gradle.kts ---\n${files.find((f) => f.path === "app/build.gradle.kts")?.content}\n` +
              `--- app/src/main/java/com/aether/app/MainActivity.kt ---\n${files.find((f) => f.path.endsWith("MainActivity.kt"))?.content}\n` +
              `--- settings.gradle.kts ---\n${files.find((f) => f.path === "settings.gradle.kts")?.content}\n\n` +
              `Исправь ошибку и верни только исправленные файлы через [[WRITE_FILE]].`;

            const fix = await councilCode(fixSystem, fixContent, ["mistral-codestral", "deepseek-v4-flash", "nex-n2-5-mini"], abort.signal);
            const { ops } = parseWriteOps(fix.content);
            if (ops.length === 0) {
              send({ type: "delta", content: "Не удалось автоматически определить исправление. Проверьте логи сборки.\n" });
              break;
            }
            for (const op of ops) {
              if (abort.signal.aborted) break;
              send({ type: "status", text: `Исправляю ${op.path}…` });
              const res = await writeFile({ token, fullName: repo, path: op.path, branch, content: op.content, message: `AETHER: авто-фикс сборки #${attempt}` });
              commits.push({ path: op.path, url: res.commitUrl, ok: res.ok, error: res.error });
              send({ type: "commit", path: op.path, ok: res.ok, url: res.commitUrl, error: res.error });
              // keep our in-memory copy in sync for the next fix round
              const idx = files.findIndex((f) => f.path === op.path);
              if (idx >= 0) files[idx] = { path: op.path, content: op.content };
              else files.push({ path: op.path, content: op.content });
            }
          }

          const summary =
            (built
              ? `🎉 Готово! Собран настоящий APK приложения **«${appName}»** (Kotlin + Jetpack Compose).\n\n📦 Скачать APK: ${runUrl} → артефакт \`app-debug-apk\`.\n\n`
              : `Создано приложение **«${appName}»** (${files.length} файлов). Сборка пока не прошла на 100% — последний запуск: ${runUrl}. Напишите «продолжи», чтобы я снова попытался починить.\n\n`) +
            "**Коммиты:**\n" + commits.slice(0, 20).map((c) => (c.ok ? `✅ \`${c.path}\`` : `❌ \`${c.path}\` — ${c.error}`)).join("\n");

          const [assistantMessage] = await db
            .insert(chatMessages)
            .values({ sessionId, role: "assistant", kind: "text", content: summary, providerSlug: "mistral-codestral", providerName: "AETHER Agent", modelId: "agent", routingReason: `GitHub agent · ${repo}@${branch}` })
            .returning();
          await db.update(chatSessions).set({ chatMode: "github", repoFullName: repo, repoBranch: branch, messageCount: history.length + 2, updatedAt: new Date() }).where(eq(chatSessions.id, sessionId));
          const sessions = await db.select().from(chatSessions).orderBy(desc(chatSessions.isPinned), desc(chatSessions.updatedAt));
          send({ type: "done", userMessage, assistantMessage, sessions, activeSessionId: sessionId });
          closed = true;
          controller.close();
          return;
        }

        // A task "needs an action" if the user asked to create/build/change things.
        const actionIntent = /созда|напиши|добав|измени|исправ|удали|собери|собрать|build|apk|workflow|коммит|commit|настрой|сделай|запусти|run/i.test(prompt);

        // Smart routing: try several coding-capable models until one actually
        // emits a tool command (instead of writing instructions).
        const modelChain = ["mistral-codestral", "gpt-oss-20b", "deepseek-v4-flash", "cohere-north-code", "mistral-nemo", "qwen3-8-27b"];

        // Agent loop: reason → act → observe → repeat
        for (let step = 0; step < MAX_STEPS; step++) {
          if (abort.signal.aborted) break;
          send({ type: "status", text: step === 0 ? "Планирую решение…" : `Шаг ${step + 1}: продолжаю…` });

          let r = await askAgent(system, convo, modelChain[0], abort.signal);
          let hasTools = parseWriteOps(r.content).ops.length > 0 || parseAgentCommands(r.content).commands.length > 0;

          // On the FIRST step, if the model just wrote instructions instead of
          // using tools, reroute to other models until one uses a tool.
          if (step === 0 && actionIntent && !hasTools) {
            for (let i = 1; i < modelChain.length && !hasTools; i++) {
              if (abort.signal.aborted) break;
              send({ type: "status", text: `Модель не выполнила действие — переключаюсь на другую (${i + 1})…` });
              const forced: ChatTurn[] = [
                ...convo,
                { role: "assistant", content: r.content },
                { role: "user", content: "Ты написал инструкцию вместо действия. НЕМЕДЛЕННО выполни задачу САМ, выведи команду [[WRITE_FILE: путь]]…[[/WRITE_FILE]] (и при необходимости [[RUN_WORKFLOW:]] / [[CHECK_BUILD]]). Без объяснений и инструкций пользователю." },
              ];
              try {
                r = await askAgent(system, forced, modelChain[i], abort.signal);
                hasTools = parseWriteOps(r.content).ops.length > 0 || parseAgentCommands(r.content).commands.length > 0;
              } catch {
                /* try next model */
              }
            }
          }

          providerName = r.providerName;
          providerSlug = r.providerSlug;
          modelId = r.modelId;

          const { ops } = parseWriteOps(r.content);
          const { commands, cleaned: afterCmds } = parseAgentCommands(parseWriteOps(r.content).cleaned);

          // Show the model's narration for this step
          if (afterCmds.trim()) {
            send({ type: "delta", content: (step > 0 ? "\n\n" : "") + afterCmds.trim() });
            transcript.push(afterCmds.trim());
          }

          const observations: string[] = [];

          // 1) Commit any file writes
          for (const op of ops) {
            if (abort.signal.aborted) break;
            send({ type: "status", text: `Коммичу ${op.path}…` });
            const res = await writeFile({ token, fullName: repo, path: op.path, branch, content: op.content, message: `AETHER agent: ${prompt.slice(0, 60)}` });
            commits.push({ path: op.path, url: res.commitUrl, ok: res.ok, error: res.error });
            send({ type: "commit", path: op.path, ok: res.ok, url: res.commitUrl, error: res.error });
            observations.push(res.ok ? `Файл ${op.path} успешно закоммичен.` : `Ошибка коммита ${op.path}: ${res.error}`);
          }

          // 2) Execute agent commands
          let didAction = ops.length > 0;
          for (const cmd of commands) {
            if (abort.signal.aborted) break;
            didAction = true;
            if (cmd.kind === "READ_FILE" && cmd.arg) {
              send({ type: "status", text: `Читаю ${cmd.arg}…` });
              const f = await readFile(token, repo, cmd.arg, branch);
              observations.push(f ? `Содержимое ${cmd.arg}:\n${f.content.slice(0, 5000)}` : `Файл ${cmd.arg} не найден.`);
            } else if (cmd.kind === "LIST_FILES") {
              observations.push(`Файлы:\n${fileList.join("\n")}`);
            } else if (cmd.kind === "RUN_WORKFLOW") {
              const wfList = await listWorkflows(token, repo);
              const wfFile = cmd.arg || wfList[0]?.path.split("/").pop() || "";
              if (!wfFile) {
                observations.push("Нет доступных workflow. Сначала создай .github/workflows/*.yml");
              } else {
                send({ type: "status", text: `Запускаю сборку: ${wfFile}…` });
                const disp = await dispatchAndTrack(token, repo, wfFile, branch, abort.signal);
                if (!disp.ok) {
                  send({ type: "action", label: `❌ Не удалось запустить ${wfFile}: ${disp.error}` });
                  observations.push(`Ошибка запуска ${wfFile}: ${disp.error}`);
                } else {
                  send({ type: "action", label: `▶️ Сборка ${wfFile} запущена` });
                  send({ type: "status", text: "⏳ Жду полного завершения раннера…" });
                  const rid = disp.runId || (await getLatestRun(token, repo))?.id;
                  const run = rid ? await waitForRunId(token, repo, rid, undefined, { signal: abort.signal }) : null;
                  if (run && run.status === "completed") {
                    const ok = run.conclusion === "success";
                    const arts = ok ? await listArtifacts(token, repo, run.id) : [];
                    send({ type: "action", label: ok ? `✅ Сборка успешна · ${arts.map((a) => a.name).join(", ") || "готово"}` : `❌ Сборка провалилась (${run.conclusion})`, url: run.htmlUrl });
                    observations.push(
                      ok
                        ? `Сборка ЗАВЕРШЕНА УСПЕШНО. Артефакты: ${arts.map((a) => a.name).join(", ") || "app-debug-apk"}. ${run.htmlUrl}`
                        : `Сборка ПРОВАЛИЛАСЬ (${run.conclusion}). Логи ошибки:\n${(await getFailedLogs(token, repo, run.id)).slice(0, 3000)}\nИсправь причину через WRITE_FILE и снова запусти RUN_WORKFLOW.`
                    );
                  } else {
                    observations.push("Раннер ещё не завершился (превышено ожидание).");
                  }
                }
              }
            } else if (cmd.kind === "CHECK_BUILD") {
              send({ type: "status", text: "Проверяю статус сборки…" });
              const latest = await getLatestRun(token, repo);
              if (latest) {
                const run = latest.status === "completed" ? latest : await waitForRunId(token, repo, latest.id, undefined, { signal: abort.signal });
                const r = run || latest;
                const ok = r.status === "completed" && r.conclusion === "success";
                let info = `Сборка: статус ${r.status}${r.conclusion ? `, результат ${r.conclusion}` : ""}. ${r.htmlUrl}`;
                if (ok) {
                  const arts = await listArtifacts(token, repo, r.id);
                  if (arts.length) info += `\nАртефакты: ${arts.map((a) => a.name).join(", ")}`;
                }
                send({ type: "action", label: `${ok ? "✅" : r.status === "completed" ? "❌" : "🔧"} ${r.status}${r.conclusion ? " · " + r.conclusion : ""}`, url: r.htmlUrl });
                observations.push(info);
              } else {
                observations.push("Пока нет ни одной сборки.");
              }
            }
          }

          // No actions left → the agent is done
          if (!didAction) break;

          // Feed observations back so the agent can continue reasoning
          convo.push({ role: "assistant", content: r.content });
          convo.push({ role: "user", content: `Результаты выполнения:\n${observations.join("\n\n")}\n\nПродолжай, если задача не завершена. Если всё готово — коротко подведи итог без команд.` });
        }

        let finalContent = transcript.join("\n\n");
        if (commits.length) {
          finalContent += "\n\n---\n**Коммиты:**\n" + commits.map((c) => (c.ok ? `✅ \`${c.path}\`${c.url ? ` — [коммит](${c.url})` : ""}` : `❌ \`${c.path}\` — ${c.error}`)).join("\n");
        }
        if (!finalContent.trim()) finalContent = "Готово.";

        const [assistantMessage] = await db
          .insert(chatMessages)
          .values({
            sessionId,
            role: "assistant",
            kind: "text",
            content: finalContent,
            providerSlug,
            providerName,
            modelId,
            routingReason: `GitHub agent · ${repo}@${branch}`,
          })
          .returning();

        await db
          .update(chatSessions)
          .set({
            title: session!.messageCount === 0 ? `GitHub · ${repo.split("/")[1] || repo}` : session!.title,
            chatMode: "github",
            repoFullName: repo,
            repoBranch: branch,
            messageCount: history.length + 2,
            updatedAt: new Date(),
          })
          .where(eq(chatSessions.id, sessionId));

        const sessions = await db.select().from(chatSessions).orderBy(desc(chatSessions.isPinned), desc(chatSessions.updatedAt));
        send({ type: "done", userMessage, assistantMessage, sessions, activeSessionId: sessionId });
      } catch (err) {
        if (!abort.signal.aborted) {
          send({ type: "error", message: err instanceof Error ? err.message : "Ошибка" });
        }
      } finally {
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      abort.abort();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
