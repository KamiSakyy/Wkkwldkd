import { NextRequest } from "next/server";
import { db } from "@/db";
import { aiProviders, chatMessages, chatSessions } from "@/db/schema";
import {
  classifyPromptIntent,
  ensureSeededDatabase,
  runArena,
  runCouncil,
  streamSmartRoutedChat,
  StreamEvent,
} from "@/lib/ai-router";
import { gatherContext } from "@/lib/web-tools";
import { searchImages, detectImageSearch } from "@/lib/image-search";
import {
  detectAnimeIntent,
  extractAnimeQuery,
  searchAnime,
  getAnimeCalendar,
} from "@/lib/anime";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

const DEFAULT_TITLE = "Новый диалог";

function deriveTitle(prompt: string, hasAttachment: boolean) {
  const clean = prompt.replace(/\s+/g, " ").trim();
  if (!clean) return hasAttachment ? "Анализ изображения" : DEFAULT_TITLE;
  return clean.length > 46 ? `${clean.slice(0, 46)}…` : clean;
}

export async function POST(req: NextRequest) {
  await ensureSeededDatabase();
  const body = await req.json().catch(() => ({}));

  const prompt = String(body.prompt || "").trim();
  const attachmentDataUrl =
    typeof body.attachmentDataUrl === "string" && body.attachmentDataUrl.startsWith("data:image/")
      ? body.attachmentDataUrl
      : null;

  if (!prompt && !attachmentDataUrl && !body.regenerate) {
    return Response.json({ error: "Пустой запрос" }, { status: 400 });
  }
  if (attachmentDataUrl && attachmentDataUrl.length > 6_000_000) {
    return Response.json({ error: "Изображение слишком большое" }, { status: 413 });
  }

  const routingMode = String(body.routingMode || "auto");
  const systemPersona = String(body.systemPersona || "universal");
  const simulateFailover = Boolean(body.simulateFailover);
  const excludeSlug = typeof body.excludeSlug === "string" ? body.excludeSlug : null;

  let sessionId = Number(body.sessionId) || 0;
  let session = null;
  if (sessionId) {
    const [existing] = await db.select().from(chatSessions).where(eq(chatSessions.id, sessionId));
    session = existing || null;
  }
  if (!session) {
    const [created] = await db
      .insert(chatSessions)
      .values({
        title: deriveTitle(prompt, Boolean(attachmentDataUrl)),
        routingMode,
        systemPersona,
      })
      .returning();
    session = created;
    sessionId = created.id;
  }

  let history = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId))
    .orderBy(asc(chatMessages.createdAt), asc(chatMessages.id));

  const isRegenerate = Boolean(body.regenerate);
  let userMessage: typeof chatMessages.$inferSelect;

  if (isRegenerate) {
    // Reuse the latest user turn instead of inserting a duplicate question
    let lastUserIndex = -1;
    for (let i = history.length - 1; i >= 0; i--) {
      if (history[i].role === "user") {
        lastUserIndex = i;
        break;
      }
    }
    if (lastUserIndex >= 0) {
      userMessage = history[lastUserIndex];
      history = history.slice(0, lastUserIndex);
    } else {
      const [inserted] = await db
        .insert(chatMessages)
        .values({ sessionId, role: "user", kind: "text", content: prompt || "Что на этом изображении?", attachmentDataUrl })
        .returning();
      userMessage = inserted;
    }
  } else {
    const [inserted] = await db
      .insert(chatMessages)
      .values({
        sessionId,
        role: "user",
        kind: "text",
        content: prompt || "Что на этом изображении?",
        attachmentDataUrl,
      })
      .returning();
    userMessage = inserted;
  }

  const countAfter = isRegenerate ? Math.max(0, (await db.select().from(chatMessages).where(eq(chatMessages.sessionId, sessionId))).length - history.length - 1) : 0;
  const effectivePrompt = isRegenerate ? userMessage.content : prompt;
  const effectiveAttachment = isRegenerate ? userMessage.attachmentDataUrl || attachmentDataUrl : attachmentDataUrl;

  const { detectedCategory } = classifyPromptIntent(effectivePrompt, routingMode, {
    hasAttachment: Boolean(effectiveAttachment),
  });

  const encoder = new TextEncoder();
  const abortController = new AbortController();
  req.signal.addEventListener("abort", () => abortController.abort());

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      const send = (payload: Record<string, unknown>) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
        } catch {
          closed = true;
        }
      };
      const emit = (event: StreamEvent) => send(event as unknown as Record<string, unknown>);

      const finalize = async (
        assistantRows: Array<typeof chatMessages.$inferSelect>,
        tokenTotal: number
      ) => {
        const isDefaultTitle = session!.title === DEFAULT_TITLE || session!.messageCount === 0;
        await db
          .update(chatSessions)
          .set({
            title: isDefaultTitle ? deriveTitle(effectivePrompt, Boolean(effectiveAttachment)) : session!.title,
            routingMode,
            systemPersona,
            messageCount: history.length + 1 + assistantRows.length + (isRegenerate ? countAfter : 0),
            totalTokens: (session!.totalTokens || 0) + tokenTotal,
            updatedAt: new Date(),
          })
          .where(eq(chatSessions.id, sessionId));

        const [sessions, providers] = await Promise.all([
          db.select().from(chatSessions).orderBy(desc(chatSessions.isPinned), desc(chatSessions.updatedAt)),
          db.select().from(aiProviders).orderBy(asc(aiProviders.priority)),
        ]);

        send({
          type: "done",
          userMessage,
          assistantMessages: assistantRows,
          sessions,
          providers,
          activeSessionId: sessionId,
        });
      };

      send({ type: "start", userMessage, activeSessionId: sessionId, intent: detectedCategory });

      try {
        // ------------------------------------------------------ IMAGE SEARCH 🖼️
        // "дай фотки/арты X" → real web image search, send previews + links.
        if (!effectiveAttachment) {
          const imgReq = detectImageSearch(effectivePrompt);
          if (imgReq.wants && imgReq.query.length >= 2) {
            emit({ type: "status", text: `Ищу картинки: ${imgReq.query}…` });
            const nsfw = /18\+|nsfw|hentai|эроти|ecchi|lewd/i.test(effectivePrompt);
            const images = await searchImages(imgReq.query, 8, !nsfw);
            if (images.length) {
              const intro = `Вот что нашла по запросу «${imgReq.query}» 🌸 (${images.length} шт.)`;
              emit({ type: "delta", content: intro });
              const [row] = await db
                .insert(chatMessages)
                .values({
                  sessionId, role: "assistant", kind: "text", content: intro,
                  providerName: "Айя · Поиск картинок", modelId: "image-search",
                  imagesData: images,
                })
                .returning();
              await finalize([row], 0);
              return;
            }
          }
        }

        // ---------------------------------------------------------- ANIME 🌸
        // Aya can find anime (Shikimori) and give playable video (AniLibria).
        if (!effectiveAttachment) {
          const animeIntent = detectAnimeIntent(effectivePrompt);
          if (animeIntent.wantsCalendar) {
            emit({ type: "status", text: "Смотрю календарь аниме…" });
            const calendar = await getAnimeCalendar(14);
            if (calendar.length) {
              const intro = "Вот ближайшие выходы серий из календаря аниме 🌸📅";
              emit({ type: "delta", content: intro });
              const [row] = await db
                .insert(chatMessages)
                .values({
                  sessionId, role: "assistant", kind: "text", content: intro,
                  providerName: "Айя · Shikimori", modelId: "shikimori-calendar",
                  animeData: { type: "calendar", items: calendar },
                })
                .returning();
              await finalize([row], 0);
              return;
            }
          } else if (animeIntent.wantsInfo || animeIntent.wantsWatch) {
            const { title } = extractAnimeQuery(effectivePrompt);
            if (title && title.length >= 2) {
              emit({ type: "status", text: `Ищу аниме «${title}»…` });
              const results = await searchAnime(title, 5);
              if (results.length) {
                const intro = animeIntent.wantsWatch
                  ? `Нашла «${results[0].russian}»! Нажми «Смотреть» и выбери серию с качеством 🌸✨`
                  : `Вот что я нашла по запросу «${title}» 🌸`;
                emit({ type: "delta", content: intro });
                const [row] = await db
                  .insert(chatMessages)
                  .values({
                    sessionId, role: "assistant", kind: "text", content: intro,
                    providerName: "Айя · Shikimori + AniLibria", modelId: "anime-search",
                    animeData: { type: "cards", items: results },
                  })
                  .returning();
                await finalize([row], 0);
                return;
              }
            }
          }
        }

        // ------------------------------------------------- LIVE WEB CONTEXT
        // Give the assistant real internet access before it answers.
        let webContext: string | null = null;
        if (!effectiveAttachment) {
          try {
            const gathered = await gatherContext(effectivePrompt, (text) => emit({ type: "status", text }));
            if (gathered) webContext = gathered.context;
          } catch {
            webContext = null;
          }
        }

        // ---------------------------------------------------------- COUNCIL
        if (detectedCategory === "council") {
          const result = await runCouncil(
            {
              prompt: effectivePrompt,
              history: history.map((m) => ({ role: m.role, content: m.content, attachmentDataUrl: m.attachmentDataUrl })),
              systemPersona,
              attachmentDataUrl: effectiveAttachment,
              webContext,
              signal: abortController.signal,
            },
            emit
          );
          const [row] = await db
            .insert(chatMessages)
            .values({
              sessionId,
              role: "assistant",
              kind: "text",
              content: result.content,
              reasoningTrace: result.reasoningTrace,
              providerSlug: result.providerSlug,
              providerName: result.providerName,
              modelId: result.modelId,
              latencyMs: result.latencyMs,
              tokensPerSec: result.tokensPerSec,
              tokenCount: result.tokenCount,
              routingReason: result.routingReason,
              failoverLog: result.failoverLog,
            })
            .returning();
          await finalize([row], result.tokenCount);
          return;
        }

        // ------------------------------------------------------------ ARENA
        if (detectedCategory === "arena") {
          const results = await runArena(
            {
              prompt: effectivePrompt,
              history: history.map((m) => ({ role: m.role, content: m.content, attachmentDataUrl: m.attachmentDataUrl })),
              systemPersona,
              attachmentDataUrl: effectiveAttachment,
              webContext,
              signal: abortController.signal,
            },
            emit
          );
          const groupKey = `arena-${Date.now()}`;
          const rows = await db
            .insert(chatMessages)
            .values(
              results.map((r) => ({
                sessionId,
                role: "assistant",
                kind: "text",
                content: r.content,
                groupKey: results.length > 1 ? groupKey : null,
                reasoningTrace: r.reasoningTrace,
                providerSlug: r.providerSlug,
                providerName: r.providerName,
                modelId: r.modelId,
                latencyMs: r.latencyMs,
                tokensPerSec: r.tokensPerSec,
                tokenCount: r.tokenCount,
                routingReason: r.routingReason,
                failoverLog: r.failoverLog,
              }))
            )
            .returning();
          await finalize(rows, results.reduce((sum, r) => sum + r.tokenCount, 0));
          return;
        }

        // ------------------------------------------------------------ STREAM
        const result = await streamSmartRoutedChat(
          {
            prompt: effectivePrompt,
            history: history.map((m) => ({ role: m.role, content: m.content, attachmentDataUrl: m.attachmentDataUrl })),
            routingMode,
            systemPersona,
            simulateFailover,
            attachmentDataUrl: effectiveAttachment,
            excludeSlug,
            webContext,
            signal: abortController.signal,
          },
          emit
        );

        const [row] = await db
          .insert(chatMessages)
          .values({
            sessionId,
            role: "assistant",
            kind: "text",
            content: result.content,
            reasoningTrace: result.reasoningTrace,
            providerSlug: result.providerSlug,
            providerName: result.providerName,
            modelId: result.modelId,
            latencyMs: result.latencyMs,
            tokensPerSec: result.tokensPerSec,
            tokenCount: result.tokenCount,
            routingReason: result.routingReason,
            failoverLog: result.failoverLog,
          })
          .returning();
        await finalize([row], result.tokenCount);
      } catch (err) {
        const aborted = abortController.signal.aborted;
        if (!aborted) {
          console.error("POST /api/chat stream error:", err);
          send({ type: "error", message: "Ошибка обработки запроса. Попробуйте ещё раз." });
        }
      } finally {
        closed = true;
        try {
          controller.close();
        } catch {
          // already closed
        }
      }
    },
    cancel() {
      abortController.abort();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
