import { NextRequest } from "next/server";
import { pickAgents, battleAnswers } from "@/lib/multi-agent";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const prompt = String(body.prompt || "").trim().slice(0, 2000);
  if (!prompt) {
    return Response.json({ error: "Пустой запрос" }, { status: 400 });
  }
  const count = Math.max(2, Math.min(4, Number(body.count) || 3));
  const agents = (await pickAgents(Array.isArray(body.agentSlugs) ? body.agentSlugs : undefined, 4)).slice(0, count);
  if (agents.length < 2) {
    return Response.json({ error: "Нужно минимум 2 активных модели" }, { status: 400 });
  }

  const encoder = new TextEncoder();
  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort());

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (o: Record<string, unknown>) => {
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(o)}\n\n`));
        } catch {
          /* closed */
        }
      };
      try {
        send({ type: "agents", agents });
        const answers = await battleAnswers({ prompt, agents, signal: abort.signal });
        if (answers.length === 0) {
          send({ type: "error", message: "Модели не ответили. Попробуйте ещё раз." });
        } else {
          send({ type: "answers", answers });
        }
        send({ type: "done" });
      } catch (err) {
        if (!abort.signal.aborted) {
          send({ type: "error", message: err instanceof Error ? err.message : "Ошибка" });
        }
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      abort.abort();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
