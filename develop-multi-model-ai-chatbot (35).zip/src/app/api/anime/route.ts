import { NextRequest } from "next/server";
import {
  searchAnime,
  getAnimeDetails,
  getAnimeCalendar,
  searchAniLibria,
  getAniLibriaEpisodes,
  browseAnime,
  getGenres,
  CatalogParams,
} from "@/lib/anime";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  try {
    if (action === "search") {
      const q = searchParams.get("q") || "";
      return Response.json({ results: await searchAnime(q, 8) });
    }
    if (action === "details") {
      const id = Number(searchParams.get("id"));
      return Response.json({ details: await getAnimeDetails(id) });
    }
    if (action === "calendar") {
      return Response.json({ calendar: await getAnimeCalendar(20) });
    }
    if (action === "browse") {
      const p: CatalogParams = {
        order: (searchParams.get("order") as CatalogParams["order"]) || "popularity",
        status: (searchParams.get("status") as CatalogParams["status"]) || undefined,
        kind: searchParams.get("kind") || undefined,
        genre: searchParams.get("genre") ? Number(searchParams.get("genre")) : undefined,
        limit: 24,
      };
      return Response.json({ results: await browseAnime(p) });
    }
    if (action === "genres") {
      return Response.json({ genres: await getGenres() });
    }
    if (action === "watch-search") {
      const q = searchParams.get("q") || "";
      return Response.json({ releases: await searchAniLibria(q, 6) });
    }
    if (action === "episodes") {
      const id = Number(searchParams.get("id"));
      return Response.json(await getAniLibriaEpisodes(id));
    }
    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : "Ошибка" }, { status: 500 });
  }
}
