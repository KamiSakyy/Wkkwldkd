import { NextRequest } from "next/server";
import { pickAgents, infiniteDialogueTurn } from "@/lib/multi-agent";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const topic = String(body.topic || "будущее искусственного интеллекта").slice(0, 200);
  const speakerSlug = String(body.speakerSlug || "");
  const userMessage = typeof body.userMessage === "string" ? body.userMessage.slice(0, 1000) : null;
  const transcript = Array.isArray(body.transcript) ? body.transcript.slice(-24) : [];
  const requestedAgents = Array.isArray(body.agentSlugs) ? body.agentSlugs : undefined;

  const agents = await pickAgents(requestedAgents);
  if (agents.length < 2) {
    return Response.json({ error: "Недостаточно активных моделей (нужно минимум 2)" }, { status: 400 });
  }

  // Whose turn: requested speaker, else rotate to the next agent after the last speaker
  let speaker = agents.find((a) => a.slug === speakerSlug);
  if (!speaker) {
    const lastSlug = transcript.length ? transcript[transcript.length - 1].slug : "";
    const lastIdx = agents.findIndex((a) => a.slug === lastSlug);
    speaker = agents[(lastIdx + 1) % agents.length];
  }

  const encoder = new TextEncoder();
  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort());

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (o: Record<string, unknown>) => {
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(o)}\n\n`));
        } catch {
          /* closed */
        }
      };
      try {
        send({ type: "agents", agents });
        send({ type: "thinking", speaker: speaker!.name, slug: speaker!.slug });
        const turn = await infiniteDialogueTurn({
          agents,
          speakerSlug: speaker!.slug,
          topic,
          transcript,
          userMessage,
          signal: abort.signal,
        });
        send({ type: "message", ...turn });

        // Suggest who speaks next so the client can keep the loop going
        const idx = agents.findIndex((a) => a.slug === speaker!.slug);
        send({ type: "next", speakerSlug: agents[(idx + 1) % agents.length].slug });
        send({ type: "done" });
      } catch (err) {
        if (!abort.signal.aborted) {
          send({ type: "error", message: err instanceof Error ? err.message : "Ошибка" });
        }
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      abort.abort();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}
