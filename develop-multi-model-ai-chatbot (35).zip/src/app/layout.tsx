import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans, Inter, JetBrains_Mono } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin", "cyrillic-ext"],
  variable: "--font-jakarta",
  weight: ["600", "700", "800"],
});

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-inter",
  weight: ["400", "500", "600"],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin", "cyrillic"],
  variable: "--font-mono",
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "Айя — милый ИИ-программист",
  description:
    "Айя (AETHER) — милая аниме-девушка ИИ-программист. Пишет код без ошибок, ищет свежее в интернете, отвечает коротко и по делу.",
  applicationName: "Айя",
  icons: { icon: "/emilia-avatar.jpg", apple: "/emilia-avatar.jpg" },
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Айя" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#050505",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${jakarta.variable} ${inter.variable} ${jetbrainsMono.variable} dark`}>
      <body className="bg-[#050505] text-zinc-100 antialiased selection:bg-white/20 selection:text-white">
        {children}
      </body>
    </html>
  );
}
