"use client";

import React, { useState } from "react";
import dynamic from "next/dynamic";
import { Play, Star, Calendar, Loader2, Tv, X } from "lucide-react";
import { searchAniLibriaClient, getEpisodesClient } from "@/lib/anilibria-client";

const CustomVideoPlayer = dynamic(() => import("@/components/VideoPlayer").then((m) => m.CustomVideoPlayer), { ssr: false });

interface AnimeCard {
  id: number;
  russian: string;
  name: string;
  image: string;
  score: number;
  episodes: number;
  status: string;
  airedOn: string | null;
}

interface AniLibRelease {
  id: number;
  name: string;
  englishName: string;
  year: number;
  episodesTotal: number;
  poster: string;
}
interface AniLibEpisode {
  ordinal: number;
  name: string | null;
  hls480: string | null;
  hls720: string | null;
  hls1080: string | null;
  raw480: string | null;
  raw720: string | null;
  raw1080: string | null;
}

// ── Full anime card with watch button + player ──────────────────────────────
export function AnimeResultCard({ card }: { card: AnimeCard }) {
  const [watching, setWatching] = useState(false);
  const [loading, setLoading] = useState(false);
  const [release, setRelease] = useState<AniLibRelease | null>(null);
  const [episodes, setEpisodes] = useState<AniLibEpisode[]>([]);
  const [ep, setEp] = useState<AniLibEpisode | null>(null);
  const [notFound, setNotFound] = useState(false);

  const openWatch = async () => {
    setWatching(true);
    setLoading(true);
    setNotFound(false);
    try {
      // Client-side (user's browser) — AniLibria blocks our server IP.
      let releases = await searchAniLibriaClient(card.russian || card.name, 3);
      if (releases.length === 0 && card.name) releases = await searchAniLibriaClient(card.name, 3);
      const rel = releases[0];
      if (!rel) {
        setNotFound(true);
        return;
      }
      const e = await getEpisodesClient(rel.id);
      setRelease(e.release || rel);
      setEpisodes(e.episodes || []);
      setEp((e.episodes || [])[0] || null);
      if (!e.episodes.length) setNotFound(true);
    } catch {
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="my-2 rounded-2xl border border-white/[0.08] bg-[#0e0e10] overflow-hidden animate-fade-in">
      <div className="flex gap-3 p-3">
        {card.image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={card.image} alt="" className="w-20 h-28 rounded-lg object-cover shrink-0 border border-white/[0.06]" loading="lazy" />
        )}
        <div className="min-w-0 flex-1">
          <div className="text-[14px] font-semibold text-zinc-100 leading-tight">{card.russian || card.name}</div>
          {card.name && card.name !== card.russian && <div className="text-[11px] text-zinc-500 truncate">{card.name}</div>}
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-zinc-400">
            {card.score > 0 && <span className="inline-flex items-center gap-1"><Star className="w-3 h-3 text-amber-400" />{card.score}</span>}
            {card.episodes > 0 && <span className="inline-flex items-center gap-1"><Tv className="w-3 h-3" />{card.episodes} эп.</span>}
            {card.airedOn && <span className="inline-flex items-center gap-1"><Calendar className="w-3 h-3" />{card.airedOn.slice(0, 4)}</span>}
            <span className="px-1.5 py-0.5 rounded bg-white/[0.05] text-[10px]">{card.status === "released" ? "вышло" : card.status === "ongoing" ? "онгоинг" : card.status}</span>
          </div>
          {!watching && (
            <button onClick={openWatch} className="mt-2.5 h-8 px-3 rounded-lg bg-white text-black text-[12px] font-semibold inline-flex items-center gap-1.5 active:scale-95">
              <Play className="w-3.5 h-3.5 fill-current" /> Смотреть
            </button>
          )}
        </div>
      </div>

      {watching && (
        <div className="border-t border-white/[0.08] p-3">
          {loading ? (
            <div className="h-40 grid place-items-center text-zinc-500"><Loader2 className="w-5 h-5 animate-spin" /></div>
          ) : notFound ? (
            <div className="text-[12px] text-zinc-500 py-4 text-center">
              Видео для этого аниме не найдено в AniLibria 😔
              <button onClick={() => setWatching(false)} className="ml-2 text-zinc-400 hover:text-white underline">закрыть</button>
            </div>
          ) : (
            <>
              {ep && (
                <CustomVideoPlayer
                  key={ep.ordinal}
                  poster={card.image}
                  sources={[
                    ...(ep.hls1080 ? [{ url: ep.hls1080, label: "1080p", downloadUrl: ep.raw1080 || undefined }] : []),
                    ...(ep.hls720 ? [{ url: ep.hls720, label: "720p", downloadUrl: ep.raw720 || undefined }] : []),
                    ...(ep.hls480 ? [{ url: ep.hls480, label: "480p", downloadUrl: ep.raw480 || undefined }] : []),
                  ]}
                />
              )}
              <div className="mt-2.5 flex items-center justify-end">
                <button onClick={() => setWatching(false)} className="w-7 h-7 rounded-md grid place-items-center text-zinc-500 hover:text-white hover:bg-white/[0.06]"><X className="w-4 h-4" /></button>
              </div>
              {episodes.length > 1 && (
                <div className="mt-2.5">
                  <div className="text-[11px] text-zinc-500 mb-1.5">Серии ({episodes.length}) · {release?.name}</div>
                  <div className="flex flex-wrap gap-1 max-h-28 overflow-y-auto">
                    {episodes.map((e) => (
                      <button
                        key={e.ordinal}
                        onClick={() => setEp(e)}
                        className={`w-8 h-8 rounded-md text-[11px] font-mono transition ${ep?.ordinal === e.ordinal ? "bg-white text-black" : "bg-white/[0.05] text-zinc-300 hover:bg-white/[0.1]"}`}
                      >
                        {e.ordinal}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ── Calendar strip ──────────────────────────────────────────────────────────
export function AnimeCalendar({ entries }: { entries: { animeId: number; russian: string; name: string; image: string; nextEpisode: number; nextEpisodeAt: string }[] }) {
  return (
    <div className="my-2 space-y-1.5 animate-fade-in">
      {entries.map((c) => {
        const d = new Date(c.nextEpisodeAt);
        const when = d.toLocaleString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
        return (
          <div key={c.animeId + "-" + c.nextEpisode} className="flex items-center gap-2.5 rounded-xl border border-white/[0.06] bg-[#0e0e10] p-2">
            {c.image && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={c.image} alt="" className="w-10 h-14 rounded object-cover shrink-0" loading="lazy" />
            )}
            <div className="min-w-0 flex-1">
              <div className="text-[13px] text-zinc-100 truncate">{c.russian || c.name}</div>
              <div className="text-[11px] text-zinc-500">Серия {c.nextEpisode} · {when}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
