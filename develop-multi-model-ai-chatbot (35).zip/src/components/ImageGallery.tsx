"use client";

import React, { useState } from "react";
import { X, ExternalLink, Download } from "lucide-react";

interface ImgItem { image: string; thumbnail: string; title: string; source: string }

export function ImageGallery({ images }: { images: ImgItem[] }) {
  const [open, setOpen] = useState<number | null>(null);

  const download = (url: string) => {
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.rel = "noopener";
    a.download = "";
    a.click();
  };

  return (
    <>
      <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-2">
        {images.map((img, i) => (
          <button key={i} onClick={() => setOpen(i)} className="group relative aspect-square rounded-xl overflow-hidden border border-white/[0.06] bg-[#111]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img.thumbnail || img.image} alt={img.title} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              onError={(e) => { (e.currentTarget as HTMLImageElement).style.opacity = "0.2"; }} />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition" />
          </button>
        ))}
      </div>

      {open !== null && (
        <div className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-sm grid place-items-center p-4 animate-fade-in" onClick={() => setOpen(null)}>
          <div className="relative max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={images[open].image} alt={images[open].title} className="w-full max-h-[80vh] object-contain rounded-xl" />
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              {images[open].title && <span className="text-[12px] text-zinc-400 flex-1 min-w-0 truncate">{images[open].title}</span>}
              <button onClick={() => download(images[open].image)} className="h-8 px-3 rounded-lg bg-white text-black text-[12px] font-semibold inline-flex items-center gap-1.5"><Download className="w-3.5 h-3.5" />Скачать</button>
              {images[open].source && (
                <a href={images[open].source} target="_blank" rel="noopener noreferrer" className="h-8 px-3 rounded-lg border border-white/[0.15] text-zinc-200 text-[12px] inline-flex items-center gap-1.5"><ExternalLink className="w-3.5 h-3.5" />Источник</a>
              )}
              <button onClick={() => setOpen(null)} className="w-8 h-8 rounded-lg border border-white/[0.15] grid place-items-center text-zinc-400 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            {images.length > 1 && (
              <div className="mt-2 flex items-center justify-center gap-2 text-[12px] text-zinc-400">
                <button onClick={() => setOpen((open - 1 + images.length) % images.length)} className="px-2 py-1 rounded hover:bg-white/10">←</button>
                <span>{open + 1} / {images.length}</span>
                <button onClick={() => setOpen((open + 1) % images.length)} className="px-2 py-1 rounded hover:bg-white/10">→</button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
