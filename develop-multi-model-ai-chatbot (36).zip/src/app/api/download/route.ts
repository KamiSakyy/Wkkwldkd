import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

const ALLOWED = /(^|\.)libria\.fun$|(^|\.)anilibria\.(top|tv)$|(^|\.)wwnd\.space$/i;

// Download an entire HLS episode as ONE .ts file: fetch the playlist, then
// stream-concatenate every segment. Forces a real file download on our site.
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const target = searchParams.get("u");
  const name = (searchParams.get("name") || "episode").replace(/[^\w.-]/g, "_");
  const kind = searchParams.get("kind"); // "image" for direct image download
  if (!target) return new Response("Missing u", { status: 400 });

  // Direct image download (any host) — proxy bytes with attachment header.
  if (kind === "image") {
    try {
      const r = await fetch(target, {
        headers: { "User-Agent": "Mozilla/5.0", Accept: "image/*,*/*" },
        signal: AbortSignal.timeout(30000),
      });
      if (!r.ok || !r.body) return new Response("Image error", { status: 502 });
      const ct = r.headers.get("content-type") || "image/jpeg";
      const ext = ct.includes("png") ? "png" : ct.includes("webp") ? "webp" : ct.includes("gif") ? "gif" : "jpg";
      return new Response(r.body, {
        headers: {
          "Content-Type": ct,
          "Content-Disposition": `attachment; filename="${name}.${ext}"`,
          "Cache-Control": "no-store",
        },
      });
    } catch {
      return new Response("Image error", { status: 502 });
    }
  }

  let playlistUrl: URL;
  try {
    playlistUrl = new URL(target);
  } catch {
    return new Response("Bad url", { status: 400 });
  }
  if (!ALLOWED.test(playlistUrl.hostname)) return new Response("Host not allowed", { status: 403 });

  const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
    Accept: "*/*",
    Referer: "https://anilibria.top/",
  };

  // Fetch & parse the playlist
  const plRes = await fetch(playlistUrl.toString(), { headers, signal: AbortSignal.timeout(30000) }).catch(() => null);
  if (!plRes || !plRes.ok) return new Response("Playlist error", { status: 502 });
  const playlist = await plRes.text();
  const base = playlistUrl.href.slice(0, playlistUrl.href.lastIndexOf("/") + 1);

  const segments = playlist
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#"))
    .map((l) => (l.startsWith("http") ? l : base + l));

  if (segments.length === 0) return new Response("No segments", { status: 502 });

  const encoder = new TextEncoder();
  void encoder;

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        for (const seg of segments) {
          if (req.signal.aborted) break;
          let ok = false;
          for (let attempt = 0; attempt < 3 && !ok; attempt++) {
            try {
              const r = await fetch(seg, { headers, signal: AbortSignal.timeout(45000) });
              if (r.ok && r.body) {
                const reader = r.body.getReader();
                while (true) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  if (value) controller.enqueue(value);
                }
                ok = true;
              }
            } catch {
              /* retry */
            }
          }
        }
      } catch {
        /* stream ends */
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "video/mp2t",
      "Content-Disposition": `attachment; filename="${name}.ts"`,
      "Cache-Control": "no-store",
    },
  });
}
